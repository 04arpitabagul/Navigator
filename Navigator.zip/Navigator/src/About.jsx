import React from "react";
import "./About.css";

const About = () => {
  return <div>Aboutpage</div>;
};

export default About;
