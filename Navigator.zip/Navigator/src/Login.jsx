import axios from "axios";
import React, { useContext, useState } from "react";
import { AuthContext } from "./Context/AuthContext";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { token, handlelogin, handlelogout } = useContext(AuthContext);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email === "eve.holt@reqres.in" && password === "cityslicka") {
      handlelogin("dummy_token_123");
    } else {
      alert("Login failed");
    }
  };

  // ✨ Stylish CSS-in-JS
  const wrapperStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "#f0f2f5",
  };

  const formStyle = {
    backgroundColor: "#fff",
    padding: "40px",
    borderRadius: "12px",
    boxShadow: "0 8px 20px rgba(0,0,0,0.1)",
    width: "100%",
    maxWidth: "400px",
    fontFamily: "Arial, sans-serif",
  };

  const headingStyle = {
    textAlign: "center",
    marginBottom: "30px",
    color: "#333",
  };

  const inputStyle = {
    width: "100%",
    padding: "12px",
    marginBottom: "20px",
    borderRadius: "6px",
    border: "1px solid #ccc",
    fontSize: "1rem",
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px",
    border: "none",
    borderRadius: "6px",
    backgroundColor: "#007bff",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    fontSize: "1rem",
  };

  const logoutButtonStyle = {
    ...buttonStyle,
    backgroundColor: "#dc3545",
    marginTop: "20px",
  };

  return (
    <div style={wrapperStyle}>
      <div style={formStyle}>
        <h1 style={headingStyle}>Login</h1>
        {!token ? (
          <form onSubmit={handleSubmit}>
            <label>Email</label>
            <input
              type="text"
              placeholder="Enter email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
            />

            <label>Password</label>
            <input
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={inputStyle}
            />

            <input type="submit" value="Login" style={buttonStyle} />
          </form>
        ) : (
          <>
            <p
              style={{
                textAlign: "center",
                fontSize: "1.1rem",
                marginBottom: "10px",
              }}
            >
              You are logged in!
            </p>
            <button onClick={handlelogout} style={logoutButtonStyle}>
              Logout
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Login;
