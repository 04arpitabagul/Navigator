import { useEffect, useState } from "react";
import axios from "axios";
import Card from "react-bootstrap/Card";
import { useNavigate } from "react-router-dom";

const Product = () => {
  const [product, setProduct] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchProduct = () => {
    setLoading(true);
    setError(null);
    axios
      .get("https://fakestoreapi.com/products")
      .then((response) => {
        setProduct(response.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Something went wrong");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProduct();
  }, []);

  const styles = {
    container: {
      paddingTop: "40px",
      paddingBottom: "40px",
    },
    card: {
      height: "100%",
      border: "1px solid #e0e0e0",
      borderRadius: "10px",
      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
      transition: "transform 0.2s ease-in-out",
    },
    cardImage: {
      objectFit: "contain",
      padding: "20px",
      height: "300px",
      backgroundColor: "#f9f9f9",
    },
    cardTitle: {
      fontSize: "1rem",
      fontWeight: "bold",
      minHeight: "50px",
    },
    cardText: {
      fontSize: "0.9rem",
      color: "#555",
      maxHeight: "80px",
      overflow: "hidden",
      textOverflow: "ellipsis",
    },
    cardPrice: {
      fontWeight: "bold",
      color: "#007bff",
      marginTop: "10px",
    },
  };

  return loading ? (
    <h1>Loading...</h1>
  ) : error ? (
    <h1>{error}</h1>
  ) : (
    <div className="container" style={styles.container}>
      <div className="row row-cols-md-3 row-cols-1 g-4">
        {product.map((el) => (
          <div
            key={el.id}
            className="col"
            onClick={() => navigate(`/product/${el.id}`)}
            style={{ cursor: "pointer" }}
          >
            <Card style={styles.card}>
              <Card.Img variant="top" src={el.image} style={styles.cardImage} />
              <Card.Body>
                <Card.Title style={styles.cardTitle}>{el.title}</Card.Title>
                <Card.Text style={styles.cardText}>{el.description}</Card.Text>
                <h5 style={styles.cardPrice}>${el.price}</h5>
              </Card.Body>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Product;
