import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const navbarStyle = {
    backgroundColor: "#1f1f1f",
    padding: "15px 0",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
    position: "sticky",
    top: 0,
    zIndex: 1000,
  };

  const containerStyle = {
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    maxWidth: "1000px",
    margin: "auto",
  };

  const linkStyle = {
    color: "#ffffff",
    textDecoration: "none",
    fontSize: "1.1rem",
    padding: "10px 20px",
    borderRadius: "8px",
    transition: "all 0.3s ease",
  };

  const hoverStyle = {
    backgroundColor: "#ffffff",
    color: "#1f1f1f",
    fontWeight: "500",
  };

  // Custom Link component with hover effect
  const HoverLink = ({ to, children }) => {
    const [hover, setHover] = React.useState(false);
    return (
      <Link
        to={to}
        style={hover ? { ...linkStyle, ...hoverStyle } : linkStyle}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        {children}
      </Link>
    );
  };

  return (
    <div style={navbarStyle}>
      <div style={containerStyle}>
        <HoverLink to="/">Home</HoverLink>
        <HoverLink to="/about">About</HoverLink>
        <HoverLink to="/product">Product</HoverLink>
        <HoverLink to="/login">Login</HoverLink>
      </div>
    </div>
  );
};

export default Navbar;
