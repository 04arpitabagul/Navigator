import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const ProductDescription = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    axios
      .get(`https://fakestoreapi.com/products/${id}`)
      .then((res) => {
        setProduct(res.data);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load product");
        setLoading(false);
      });
  }, [id]);

  if (loading)
    return (
      <h2 style={{ textAlign: "center", marginTop: "50px" }}>Loading...</h2>
    );
  if (error)
    return (
      <h2 style={{ textAlign: "center", color: "red", marginTop: "50px" }}>
        {error}
      </h2>
    );

  const containerStyle = {
    maxWidth: "800px",
    margin: "60px auto",
    padding: "30px",
    borderRadius: "12px",
    boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#fff",
  };

  const imageStyle = {
    maxHeight: "300px",
    objectFit: "contain",
    marginBottom: "30px",
  };

  const titleStyle = {
    fontSize: "1.8rem",
    fontWeight: "bold",
    marginBottom: "15px",
    color: "#333",
  };

  const descriptionStyle = {
    fontSize: "1rem",
    color: "#555",
    marginBottom: "25px",
    lineHeight: "1.6",
  };

  const priceStyle = {
    fontSize: "1.5rem",
    color: "#007bff",
    marginBottom: "10px",
  };

  const categoryStyle = {
    fontStyle: "italic",
    color: "#888",
  };

  return (
    product && (
      <div style={containerStyle}>
        <img src={product.image} alt={product.title} style={imageStyle} />
        <h2 style={titleStyle}>{product.title}</h2>
        <p style={descriptionStyle}>{product.description}</p>
        <h3 style={priceStyle}>${product.price}</h3>
        <p style={categoryStyle}>{product.category}</p>
      </div>
    )
  );
};

export default ProductDescription;
